﻿
namespace Ex03.ConsoleUI
{
    class Program
    {
        public static void Main()
        {
            GarageLogicUI garageLogicUI = new GarageLogicUI();
            garageLogicUI.StartMenuGarage();
        }
    }
}
